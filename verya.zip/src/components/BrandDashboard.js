import React, { useState } from "react";
import './BrandDashboard.css';

import tshirtImage from '../images/tshirt.jpg';
import jeansImage from '../images/jeans.jpg';
import sneakersImage from '../images/sneakers.jpg';
import hatImage from '../images/hat.jpg';

const BrandDashboard = () => {
  const [activeSection, setActiveSection] = useState("inventory");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const inventoryItems = [
    { id: 1, name: "T-shirt", imgUrl: tshirtImage, price: "$19.99", stock: 50 },
    { id: 2, name: "Jeans", imgUrl: jeansImage, price: "$39.99", stock: 30 },
    { id: 3, name: "Sneakers", imgUrl: sneakersImage, price: "$59.99", stock: 100 },
    { id: 4, name: "Hat", imgUrl: hatImage, price: "$15.99", stock: 25 },
  ];

  const orders = [
    { orderId: "ORD001", product: "T-shirt", status: "Shipped" },
    { orderId: "ORD002", product: "Jeans", status: "Processing" },
  ];

  const analytics = {
    totalSales: "$1200",
    totalOrders: 50,
    customers: 35,
    views: 1200,
    clicks: 300
  };

  const renderSection = () => {
    switch (activeSection) {
      case "inventory":
        return (
          <div className="dashboard-section">
            <h3>Your Inventory</h3>
            <div className="card-container">
              {inventoryItems.map((item) => (
                <div key={item.id} className="product-card">
                  <img src={item.imgUrl} alt={item.name} className="product-img" />
                  <h4>{item.name}</h4>
                  <p>{item.price}</p>
                  <p>Stock: {item.stock}</p>
                  <div className="button-group">
                    <button className="action-btn">View Product</button>
                    <button className="action-btn">Edit</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case "orders":
        return (
          <div className="dashboard-section">
            <h3>Recent Orders</h3>
            <div className="orders-container">
              {orders.map((order, index) => (
                <div key={index} className="order-item">
                  <h4>{order.orderId}</h4>
                  <p>Product: {order.product}</p>
                  <p>Status: {order.status}</p>
                  <button className="action-btn">Mark as Shipped</button>
                </div>
              ))}
            </div>
          </div>
        );
      case "analytics":
        return (
          <div className="dashboard-section">
            <h3>Analytics</h3>
            <div className="analytics-grid">
              <div className="analytics-card">
                <h4>📊 Total Sales</h4>
                <p>{analytics.totalSales}</p>
              </div>
              <div className="analytics-card">
                <h4>📦 Orders</h4>
                <p>{analytics.totalOrders}</p>
              </div>
              <div className="analytics-card">
                <h4>👥 Customers</h4>
                <p>{analytics.customers}</p>
              </div>
              <div className="analytics-card">
                <h4>👀 Views</h4>
                <p>{analytics.views}</p>
              </div>
              <div className="analytics-card">
                <h4>🖱️ Clicks</h4>
                <p>{analytics.clicks}</p>
              </div>
            </div>
          </div>
        );
      case "upload":
        return (
          <div className="dashboard-section">
            <h3>Upload New Product</h3>
            <form>
              <input className="form-input" type="text" placeholder="Product Title" />
              <input className="form-input" type="number" placeholder="Price" />
              <input className="form-input" type="number" placeholder="Stock Quantity" />
              <input className="form-input" type="file" />
              <button className="action-btn" type="submit">Upload Product</button>
            </form>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="brand-dashboard-container">
      {/* Sidebar */}
      {sidebarOpen && (
        <div className="sidebar">
          <ul>
            <li className={activeSection === "inventory" ? "active" : ""} onClick={() => setActiveSection("inventory")}>Inventory Management</li>
            <li className={activeSection === "orders" ? "active" : ""} onClick={() => setActiveSection("orders")}>Order Management</li>
            <li className={activeSection === "analytics" ? "active" : ""} onClick={() => setActiveSection("analytics")}>Analytics</li>
            <li className={activeSection === "upload" ? "active" : ""} onClick={() => setActiveSection("upload")}>Upload Product</li>
          </ul>
        </div>
      )}

      {/* Toggle Sidebar Button */}
      <button className="sidebar-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
        {sidebarOpen ? "✖" : "☰"}
      </button>

      {/* Main Content */}
      <div className="dashboard-content">
        <h2>Brand Dashboard</h2>
        {renderSection()}
      </div>
    </div>
  );
};

export default BrandDashboard;
