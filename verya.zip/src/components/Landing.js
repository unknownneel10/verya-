import React from 'react';
import { useNavigate } from 'react-router-dom';

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome to Veyra</h1>
      <p>Reimagining how people discover and shop fashion.</p>
      <button onClick={() => navigate('/login/user')} style={{ marginRight: '10px' }}>Login as User</button>
      <button onClick={() => navigate('/login/brand')}>Login as Brand</button>
    </div>
  );
};

export default Landing;
