import React, { useState, useRef } from "react";
import './UserDashboard.css';

import tshirtImage from '../images/tshirt.jpg';
import jeansImage from '../images/jeans.jpg';
import sneakersImage from '../images/sneakers.jpg';
import hatImage from '../images/hat.jpg';

const UserDashboard = () => {
  const productsRef = useRef(null);
  const discoverRef = useRef(null);
  const profileRef = useRef(null); 

  const scrollToProducts = () => {
    productsRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToDiscover = () => {
    discoverRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToProfile = () => {
    profileRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const productItems = [
    { id: 1, name: "T-shirt", imgUrl: tshirtImage, price: "$19.99" },
    { id: 2, name: "Jeans", imgUrl: jeansImage, price: "$39.99" },
    { id: 3, name: "Sneakers", imgUrl: sneakersImage, price: "$59.99" },
    { id: 4, name: "Hat", imgUrl: hatImage, price: "$15.99" },
  ];

  const [feedItems] = useState([
    {
      id: 1,
      user: "John Doe",
      content: "Loving my new sneakers! 👟",
      imgUrl: sneakersImage,
      likes: 5,
      comments: 2,
    },
    {
      id: 2,
      user: "Jane Smith",
      content: "Just bought these amazing jeans! 👖",
      imgUrl: jeansImage,
      likes: 8,
      comments: 3,
    },
    {
      id: 3,
      user: "Alex Brown",
      content: "This t-shirt is so comfy! 😊",
      imgUrl: tshirtImage,
      likes: 12,
      comments: 5,
    },
    {
      id: 4,
      user: "Lisa White",
      content: "My new hat collection is complete! 🎩",
      imgUrl: hatImage,
      likes: 7,
      comments: 1,
    },
  ]);

  
  const discoverItems = [
    {
      id: 1,
      title: "Watches from Different Brands",
      description: "Explore a variety of watches, from luxury brands to sporty designs.",
      imgUrl: 'watches.jpg', 
    },
    {
      id: 2,
      title: "Gym Activewear",
      description: "Get your fitness on with our latest collection of gym wear - leggings, tanks, and more!",
      imgUrl: 'gym-activewear.jpg', 
    },
    {
      id: 3,
      title: "Trending Fashion Accessories",
      description: "From sunglasses to belts, check out this season's hottest accessories.",
      imgUrl: 'accessories.jpg', 
    },
    {
      id: 4,
      title: "Sale on Shoes",
      description: "Huge discounts on shoes - sneakers, boots, and sandals for every occasion.",
      imgUrl: 'shoes.jpg', 
    }
  ];

  
  const userProfile = {
    name: "Neel Joshi",
    location: "Pune",
    followers: 111,
    following: 222,
    bio: "Fashion enthusiast | Sharing my wardrobe picks with the world. Always on the lookout for stylish, comfortable clothing. #FashionForAll"
  };

  return (
    <div className="user-dashboard-container">
      {/* Navigation */}
      <nav className="top-nav">
        <ul>
          <li onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>Feed</li>
          <li onClick={scrollToDiscover}>Discover</li>
          <li>Upload</li>
          <li onClick={scrollToProducts}>Products</li>
          <li onClick={scrollToProfile}>Profile</li> {/* Profile link */}
        </ul>
      </nav>

      {/* User Profile Section */}
      <div className="user-profile" ref={profileRef}>
        <div className="profile-header">
          <div className="profile-info">
            <h2>{userProfile.name}</h2>
            <p>{userProfile.location}</p>
            <p>{userProfile.bio}</p>
          </div>
        </div>
        <div className="profile-stats">
          <span>{userProfile.followers} Followers</span>
          <span>{userProfile.following} Following</span>
        </div>
      </div>

      <h2>User Dashboard</h2>

      {/* Feed Section */}
      <div className="dashboard-section">
        <h3>Your Feed</h3>
        <div className="feed-container">
          {feedItems.map((item) => (
            <div key={item.id} className="feed-item">
              <div className="feed-header">
                <strong>{item.user}</strong>
                <p>{item.content}</p>
              </div>
              <div className="feed-img-container">
                <img src={item.imgUrl} alt={item.content} className="feed-img" />
              </div>
              <div className="feed-footer">
                <span>{item.likes} Likes</span>
                <span>{item.comments} Comments</span>
              </div>
              <div className="feed-actions">
                <button className="action-btn">Like</button>
                <button className="action-btn">Comment</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Discover Section */}
      <div className="dashboard-section" ref={discoverRef}>
        <h3>Discover New Items</h3>
        <div className="discover-container">
          {discoverItems.map((item) => (
            <div key={item.id} className="discover-item">
              <div className="discover-image-container">
                <img src={item.imgUrl} alt={item.title} className="discover-item-img" />
              </div>
              <div className="discover-item-content">
                <h4>{item.title}</h4>
                <p>{item.description}</p>
                <button className="action-btn">Explore</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Products Section */}
      <div className="dashboard-section" ref={productsRef}>
        <h3>Your Products</h3>
        <div className="card-container">
          {productItems.map((item) => (
            <div key={item.id} className="product-card">
              <img src={item.imgUrl} alt={item.name} className="product-img" />
              <h4>{item.name}</h4>
              <p>{item.price}</p>
              <div className="button-group">
                <button className="action-btn">View Item</button>
                <button className="action-btn">Add to Cart</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
