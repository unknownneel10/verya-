import React from "react";
import "./Login.css";
import { useNavigate } from "react-router-dom";

function LoginBrand() {
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
   
    navigate("/dashboard/brand");
  };

  return (
    <div className="login-container">
      <h2>Brand Login</h2>
      <form className="login-form" onSubmit={handleSubmit}>
        <input type="email" placeholder="Business Email" required />
        <input type="password" placeholder="Password" required />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default LoginBrand;
