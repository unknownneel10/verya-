import React from "react";
import { BrowserRouter as Router, Routes, Route, useNavigate } from "react-router-dom";
import "./App.css";
import LoginUser from './components/LoginUser';
import LoginBrand from './components/LoginBrand';
import UserDashboard from './components/UserDashboard';
import BrandDashboard from './components/BrandDashboard';

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div className="App">
      <header className="landing-header">
        <h1>Veyra</h1>
        <p>
          Veyra is a social commerce platform reimagining how people discover and shop fashion.
        </p>
        <div className="buttons">
          <button className="user-btn" onClick={() => navigate("/login/user")}>Login as User</button>
          <button className="brand-btn" onClick={() => navigate("/login/brand")}>Login as Brand</button>
        </div>
      </header>
    </div>
  );
};

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login/user" element={<LoginUser />} />
        <Route path="/login/brand" element={<LoginBrand />} />
        <Route path="/dashboard/user" element={<UserDashboard />} />
        <Route path="/dashboard/brand" element={<BrandDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
